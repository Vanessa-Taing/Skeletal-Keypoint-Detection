import json
from pathlib import Path

ROOT = Path.home() / "skeletal_keypoint_detection"
BASE = ROOT / "experiments/RO2_Final_Patched"
ORIGINAL = ROOT / "datasets/InnoCount_COCO_Patched_UniqueIDs_v1"
MANIFEST = BASE / (
    "YOLO26n_E09_FrozenSharedProposals/shared_proposals.jsonl"
)
OUTPUT = BASE / "SharedProposalDataset"

assert MANIFEST.is_file()
assert not OUTPUT.exists(), f"Output already exists: {OUTPUT}"

coco = json.loads(
    (ORIGINAL / "annotations/test.json").read_text()
)

records = [
    json.loads(line)
    for line in MANIFEST.read_text().splitlines()
    if line.strip()
]

assert len(coco["images"]) == 74
assert len(coco["annotations"]) == 1626
assert len(records) == 1626

lookup = {}
for record in records:
    key = (int(record["image_id"]), int(record["annotation_id"]))
    assert key not in lookup
    lookup[key] = record

assert len(lookup) == 1626

new_annotations = []

for original in coco["annotations"]:
    key = (
        int(original["image_id"]),
        int(original["id"]),
    )
    assert key in lookup
    record = lookup[key]

    assert int(original["category_id"]) == int(
        record["category_id"]
    )

    assert all(
        abs(float(a) - float(b)) < 1e-3
        for a, b in zip(
            original["bbox"], record["gt_bbox_xywh"]
        )
    )

    if not record["matched"]:
        assert record["proposal_bbox_xyxy"] is None
        continue

    x1, y1, x2, y2 = map(
        float, record["proposal_bbox_xyxy"]
    )

    assert x2 > x1 and y2 > y1

    ann = dict(original)
    ann["bbox"] = [x1, y1, x2 - x1, y2 - y1]
    ann["area"] = (x2 - x1) * (y2 - y1)

    # GT keypoints and all annotation identities stay unchanged.
    new_annotations.append(ann)

assert len(new_annotations) == 1424

new_coco = dict(coco)
new_coco["annotations"] = new_annotations

(OUTPUT / "annotations").mkdir(parents=True)
(OUTPUT / "images").mkdir()

(OUTPUT / "images/test").symlink_to(
    (ORIGINAL / "images/test").resolve(),
    target_is_directory=True,
)

(OUTPUT / "annotations/test.json").write_text(
    json.dumps(new_coco, indent=2)
)

print("PASS: Proposal-conditioned COCO dataset created")
print("Output:", OUTPUT)
print("Images:", len(new_coco["images"]))
print("Matched annotations:", len(new_annotations))
print("Unmatched objects excluded from inference:", 202)
print("Original dataset: unchanged")
