import json
from collections import defaultdict
from pathlib import Path

import numpy as np
from ultralytics import YOLO

from evaluate_yolo26_pose import (
    annotation_to_gt,
    extract_yolo_predictions,
    match_instances,
)

ROOT = Path.home() / "skeletal_keypoint_detection"

ANN = ROOT / (
    "datasets/InnoCount_COCO_Patched_UniqueIDs_v1"
    "/annotations/test.json"
)

IMAGES = ROOT / (
    "datasets/InnoCount_KeyPoint_YOLO26_Pose_Patched_v1"
    "/images/test"
)

WEIGHTS = ROOT / (
    "experiments/YOLO26_Pose_Runs/"
    "E09_YOLO26n_Patched_v1/weights/best.pt"
)

OUT = ROOT / (
    "experiments/RO2_Final_Patched/"
    "YOLO26n_E09_FrozenSharedProposals"
)

assert ANN.is_file()
assert WEIGHTS.is_file()
assert IMAGES.is_dir()

# Refuse to overwrite a previous proposal export.
OUT.mkdir(parents=True, exist_ok=False)

coco = json.loads(ANN.read_text())

assert len(coco["images"]) == 74
assert len(coco["annotations"]) == 1626

by_filename = {}
for image in coco["images"]:
    name = Path(image["file_name"]).name
    assert name not in by_filename
    by_filename[name] = image

by_image = defaultdict(list)
for ann in coco["annotations"]:
    by_image[int(ann["image_id"])].append(ann)

image_paths = sorted(
    p for p in IMAGES.rglob("*")
    if p.is_file() and p.suffix.lower() in
    {".jpg", ".jpeg", ".png"}
)

assert len(image_paths) == 74
assert {p.name for p in image_paths} == set(by_filename)

model = YOLO(str(WEIGHTS))

results = model.predict(
    source=[str(p) for p in image_paths],
    imgsz=640,
    batch=1,
    conf=0.001,
    max_det=600,
    device=0,
    stream=False,
    save=False,
    verbose=False,
)

assert len(results) == len(image_paths)

records = []
matched_count = 0

for image_path, result in zip(image_paths, results):
    image = by_filename[image_path.name]
    image_id = int(image["id"])
    anns = by_image[image_id]

    gt_boxes = np.asarray(
        [annotation_to_gt(a, image)[0] for a in anns],
        dtype=np.float32,
    ).reshape(-1, 4)

    gt_classes = np.asarray(
        [int(a["category_id"]) for a in anns],
        dtype=np.int64,
    )

    boxes, classes, confidences, keypoints = (
        extract_yolo_predictions(result)
    )

    matches, _, _ = match_instances(
        gt_boxes=gt_boxes,
        gt_classes=gt_classes,
        pred_boxes=boxes,
        pred_classes=classes,
        pred_confidences=confidences,
        iou_threshold=0.50,
    )

    for index, ann in enumerate(anns):
        pred_index = matches.get(index)

        record = {
            "image_id": image_id,
            "image_file": image_path.name,
            "annotation_id": int(ann["id"]),
            "category_id": int(ann["category_id"]),
            "gt_bbox_xywh": ann["bbox"],
            "matched": pred_index is not None,
            "proposal_bbox_xyxy": None,
            "yolo_keypoints_xy": None,
            "confidence": None,
        }

        if pred_index is not None:
            j = int(pred_index)

            record["proposal_bbox_xyxy"] = (
                boxes[j].tolist()
            )
            record["yolo_keypoints_xy"] = (
                keypoints[j].tolist()
            )
            record["confidence"] = float(
                confidences[j]
            )
            matched_count += 1

        records.append(record)

assert len(records) == 1626
assert len({
    (r["image_id"], r["annotation_id"])
    for r in records
}) == 1626

manifest = OUT / "shared_proposals.jsonl"

with manifest.open("w") as f:
    for record in records:
        f.write(json.dumps(record) + "\n")

summary = {
    "protocol": "whole-image YOLO detected-box proposals",
    "checkpoint": str(WEIGHTS),
    "annotation_file": str(ANN),
    "images": 74,
    "gt_objects": len(records),
    "matched_objects": matched_count,
    "unmatched_objects": len(records) - matched_count,
    "confidence_threshold": 0.001,
    "matching_iou_threshold": 0.50,
    "max_det": 600,
}

(OUT / "proposal_summary.json").write_text(
    json.dumps(summary, indent=2)
)

print("\nSHARED PROPOSAL EXPORT")
print("=" * 50)
print("GT objects:", len(records))
print("Matched:", matched_count)
print("Unmatched:", len(records) - matched_count)
print("Manifest:", manifest)
