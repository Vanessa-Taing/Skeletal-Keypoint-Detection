#!/usr/bin/env python3

import argparse
import json
from collections import Counter
from pathlib import Path
import sys

import cv2
import numpy as np
from ultralytics import YOLO

ROOT = Path(__file__).resolve().parents[2]

sys.path.insert(
    0, str(ROOT / "scripts/evaluate")
)

from common_pose_metrics import (
    calculate_all_metrics,
    make_category_map_from_coco,
    normalize_profile_name,
)

from evaluate_yolo26_pose import (
    annotation_to_gt,
    calculate_iou_matrix,
)


def make_crop(image, bbox, padding=1.25):
    H, W = image.shape[:2]
    x, y, w, h = map(float, bbox)

    assert w > 0 and h > 0

    cx = x + w / 2
    cy = y + h / 2
    side = max(w, h) * padding

    left = int(np.floor(cx - side / 2))
    top = int(np.floor(cy - side / 2))
    right = int(np.ceil(cx + side / 2))
    bottom = int(np.ceil(cy + side / 2))

    x0, x1 = max(0, left), min(W, right)
    y0, y1 = max(0, top), min(H, bottom)

    if x1 <= x0 or y1 <= y0:
        raise ValueError("Invalid crop dimensions")

    crop = image[y0:y1, x0:x1]

    crop = cv2.copyMakeBorder(
        crop,
        y0 - top,
        bottom - y1,
        x0 - left,
        right - x1,
        cv2.BORDER_CONSTANT,
        value=(114, 114, 114),
    )

    return crop, left, top


def select_annotations(annotations, per_class):
    if per_class == 0:
        return sorted(
            annotations,
            key=lambda a: (
                a["image_id"], a["id"]
            )
        )

    density = Counter(
        a["image_id"] for a in annotations
    )

    selected = []

    for category_id in sorted(set(
        a["category_id"] for a in annotations
    )):
        rows = [
            a for a in annotations
            if a["category_id"] == category_id
        ]

        rows.sort(
            key=lambda a: (
                density[a["image_id"]],
                a["image_id"],
                a["id"],
            )
        )

        n = min(per_class, len(rows))
        indices = np.linspace(
            0, len(rows) - 1, n, dtype=int
        )

        selected.extend(rows[int(i)] for i in indices)

    return selected


def json_default(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.floating):
        return float(value)
    if isinstance(value, np.bool_):
        return bool(value)
    raise TypeError(str(type(value)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--per-class", type=int, default=10,
        help="Samples per class; 0 evaluates all instances"
    )
    args = parser.parse_args()

    assert args.per_class >= 0

    data = ROOT / (
        "datasets/InnoCount_COCO_Patched_UniqueIDs_v1"
    )

    weights = ROOT / (
        "experiments/YOLO26_Pose_Runs/"
        "E09_YOLO26n_Patched_v1/weights/best.pt"
    )

    if args.per_class == 0:
        run_name = "YOLO26n_E09_GTGuided_All"
    else:
        run_name = "YOLO26n_E09_GTGuided_Pilot"

    output = ROOT / (
        "experiments/RO2_Final_Patched"
    ) / run_name

    assert weights.is_file()
    assert (data / "annotations/test.json").is_file()

    coco = json.loads(
        (data / "annotations/test.json").read_text()
    )

    assert len(coco["images"]) == 74
    assert len(coco["annotations"]) == 1626

    image_map = {
        int(im["id"]): im for im in coco["images"]
    }

    category_map = make_category_map_from_coco(coco)

    model = YOLO(str(weights))

    model_names = (
        model.names
        if isinstance(model.names, dict)
        else dict(enumerate(model.names))
    )

    yolo_class_names = {
        int(k): normalize_profile_name(v)
        for k, v in model_names.items()
    }

    assert set(category_map.values()).issubset(
        set(yolo_class_names.values())
    ), (
        "YOLO and COCO class names are inconsistent: "
        f"{yolo_class_names} versus {category_map}"
    )

    selected = select_annotations(
        coco["annotations"], args.per_class
    )

    predictions = []
    gt = []
    gt_vis = []
    bboxes = []
    category_ids = []
    prediction_valid = []
    audit = []

    last_image_id = None
    last_image = None

    for i, ann in enumerate(selected):
        image_id = int(ann["image_id"])
        info = image_map[image_id]

        if image_id != last_image_id:
            path = (
                data / "images/test"
                / Path(info["file_name"]).name
            )
            last_image = cv2.imread(str(path))
            assert last_image is not None, path
            last_image_id = image_id

        image = last_image

        box, joints, visibility = annotation_to_gt(
            ann, info
        )

        crop, left, top = make_crop(
            image, ann["bbox"]
        )

        result = model.predict(
            source=crop,
            imgsz=640,
            conf=0.001,
            max_det=100,
            device=0,
            verbose=False,
            save=False,
        )[0]

        predicted = np.zeros((6, 2), dtype=np.float32)
        valid = False
        selected_iou = 0.0
        selected_confidence = None

        count = (
            len(result.boxes)
            if result.boxes is not None else 0
        )

        if count > 0 and result.keypoints is not None:
            boxes = (
                result.boxes.xyxy.cpu().numpy()
            )
            classes = (
                result.boxes.cls.cpu().numpy()
                .astype(int)
            )
            confidences = (
                result.boxes.conf.cpu().numpy()
            )

            target_name = category_map[
                int(ann["category_id"])
            ]

            eligible = [
                j for j, cls in enumerate(classes)
                if yolo_class_names[int(cls)] == target_name
            ]

            if eligible:
                target_box = box.copy()
                target_box[[0, 2]] -= left
                target_box[[1, 3]] -= top

                ious = calculate_iou_matrix(
                    target_box[None, :],
                    boxes[eligible],
                )[0]

                # Highest IoU, then confidence, then index
                ranked = sorted(
                    range(len(eligible)),
                    key=lambda k: (
                        -float(ious[k]),
                        -float(confidences[eligible[k]]),
                        eligible[k],
                    ),
                )

                k = ranked[0]
                best = eligible[k]
                selected_iou = float(ious[k])

                # No spatial overlap is treated as no match
                if selected_iou > 0:
                    kp = (
                        result.keypoints.xy
                        .cpu().numpy()[best]
                    )

                    predicted = kp.astype(np.float32)
                    predicted += np.array(
                        [left, top], dtype=np.float32
                    )

                    selected_confidence = float(
                        confidences[best]
                    )
                    valid = True

        predictions.append(predicted)
        gt.append(joints)
        gt_vis.append(visibility)
        bboxes.append(ann["bbox"])
        category_ids.append(int(ann["category_id"]))
        prediction_valid.append([valid] * 6)

        audit.append({
            "annotation_id": int(ann["id"]),
            "image_id": image_id,
            "filename": info["file_name"],
            "profile": category_map[int(ann["category_id"])],
            "num_candidates": count,
            "matched": valid,
            "selected_iou": selected_iou,
            "selected_confidence": selected_confidence,
        })

        print(
            f"[{i+1}/{len(selected)}] "
            f"{info['file_name']} "
            f"{category_map[int(ann['category_id'])]} "
            f"candidates={count} "
            f"matched={valid} "
            f"IoU={selected_iou:.3f}"
        )

    assert len(predictions) == len(selected)

    arrays = {
        "predictions": np.asarray(
            predictions, dtype=np.float32
        ),
        "gt": np.asarray(gt, dtype=np.float32),
        "gt_vis": np.asarray(
            gt_vis, dtype=np.float32
        ),
        "bboxes": np.asarray(
            bboxes, dtype=np.float32
        ),
        "category_ids": np.asarray(
            category_ids, dtype=np.int64
        ),
        "prediction_valid": np.asarray(
            prediction_valid, dtype=bool
        ),
    }

    metrics = calculate_all_metrics(
        **arrays,
        category_map=category_map,
        threshold=0.05,
    )

    output.mkdir(parents=True, exist_ok=True)

    np.savez_compressed(
        output / "aligned_predictions.npz",
        **arrays,
        annotation_ids=np.asarray([
            a["id"] for a in selected
        ], dtype=np.int64),
        image_ids=np.asarray([
            a["image_id"] for a in selected
        ], dtype=np.int64),
    )

    report = {
        "protocol": "GT-region-guided YOLO detection and pose",
        "model": str(weights),
        "annotations": str(
            data / "annotations/test.json"
        ),
        "per_class": args.per_class,
        "num_objects": len(selected),
        "num_matched": sum(
            row["matched"] for row in audit
        ),
        "metrics": metrics,
    }

    (output / "metrics.json").write_text(
        json.dumps(report, indent=2, default=json_default)
    )

    (output / "selection_audit.json").write_text(
        json.dumps(audit, indent=2, default=json_default)
    )

    standard = metrics["standard_pck"]
    matched = report["num_matched"]

    print("\n" + "=" * 55)
    print("GT-GUIDED YOLO EVALUATION")
    print("=" * 55)
    print("Objects:", len(selected))
    print("Matched:", matched)
    print("Coverage:", matched / len(selected))
    print("PCK@0.05:", standard["overall"])
    print("Correct:", standard["total_correct"])
    print("Valid:", standard["total_valid"])
    print("Output:", output)


if __name__ == "__main__":
    main()
