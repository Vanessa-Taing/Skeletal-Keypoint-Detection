# RO2 Reproducibility Archive

Generated: 20261113_160940

## Status
Priority 1: Shared-proposal evaluation completed.
Priority 2: ViTPose metric reconciliation completed.
Priority 3: Reproducibility archive generated.

## Evaluated test set
74 images; 1626 instances; 7049 valid keypoints.

## Frozen proposal source
1424 matched; 202 unmatched; matching IoU >= 0.50.

## Final shared-proposal PCK@0.05
Matched-only:
- YOLO26n-Pose: 0.142013
- HRNet-W32: 0.286262
- ViTPose-B: 0.568690

Full-test:
- YOLO26n-Pose: 0.126117
- HRNet-W32: 0.254220
- ViTPose-B: 0.505036

## GT-box pose comparison
- HRNet-W32: 0.337069
- ViTPose-B: 0.613562

## Important limitation
YOLO predicts poses from full images. HRNet and
ViTPose estimate poses from object crops. Shared
object proposals do not make all inference inputs
or network architectures identical.

Sheet Pile had no matched shared proposals.

## Archive contents
- source_snapshot/
- external_source_snapshot/
- dataset_annotations/
- evidence/
- environment/
- input_sha256_manifest.json
- included_evidence_manifest.json
- verification_summary.json
- Priority2_Metric_Reconciliation.md

Large model weights and image files are NOT copied
into this archive. Their SHA-256 hashes and original
paths are recorded for verification.

Dataset hash mode:
full dataset derivatives

Keep this archive together with the checkpoint and
dataset files. It is an evidence archive, not a
fully self-contained training distribution.
