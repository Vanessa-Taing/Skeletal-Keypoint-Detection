# ViTPose-B metric reconciliation

Status: Completed with a small unresolved residual.

Checkpoint: E03 epoch_90.pth
Test population: 74 images, 1626 annotations
PCK threshold: 0.05
Normalization: maximum GT bounding-box dimension

Native MMPose macro PCK: 0.597288
Recalculated macro PCK: 0.596753
Shared micro PCK: 0.613562

Micro correct / valid: 4325 / 7049

Principal explanation: macro versus micro averaging.

Residual native-versus-recalculated macro difference:
approximately 0.000535 (0.0535 percentage points).

The shared micro score was reproduced exactly from
saved predictions.

The exact prediction-level cause of the residual
difference has not been established.

These findings were supplied from the separate
Priority 2 reconciliation investigation.
The original reconciliation scripts and logs should
also be retained when available.
